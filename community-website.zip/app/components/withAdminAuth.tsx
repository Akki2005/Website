"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import type React from "react"

export function withAdminAuth(WrappedComponent: React.ComponentType) {
  return function WithAdminAuth(props: any) {
    const router = useRouter()

    useEffect(() => {
      const isLoggedIn = localStorage.getItem("isAdminLoggedIn")
      if (isLoggedIn !== "true") {
        router.push("/login")
      }
    }, [router])

    return <WrappedComponent {...props} />
  }
}

